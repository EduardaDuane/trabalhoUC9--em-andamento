package conexao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author EDUARDADUANEDOSSANTO
 */
public class Conexao {
    public static Connection conectar(){
       
        Connection conexao = null;
        
        String url = "jdbc:postgresql://localhost/AutoManager_261T";
        String usuario = "postgres";
        String senha = "root";
        
        try{
            conexao = DriverManager.getConnection(url,usuario,senha);
            System.out.println("banco conectado com sucesso");

        } catch (SQLException erro){
            System.out.println("Erro au conectar com o Banco - Erro: "+ erro);
        }
        return conexao;
    }
}
