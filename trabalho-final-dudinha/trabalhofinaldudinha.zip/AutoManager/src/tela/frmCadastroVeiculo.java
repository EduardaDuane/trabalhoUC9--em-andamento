package tela;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author EDUARDADUANEDOSSANTO
 */
public class frmCadastroVeiculo extends javax.swing.JFrame {
private void limparCampos(){
    txtIdCliente.setText("");
    txtResultadoIdCliente.setText("");
    txtPlaca.setText("");
    txtMarca.setText("");
    txtModelo.setText("");
    txtAno.setText("");
    txtCor.setText("");
    txtObservacoes.setText("");
    cbAtivo.setSelected(true);
    
}
    
    public frmCadastroVeiculo() {
    initComponents();
    txtIdVeiculo.setEditable(false);
    txtResultadoIdCliente.setEditable(false);
    cbAtivo.setSelected(true);
}
    

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtMarca = new javax.swing.JTextField();
        txtCor = new javax.swing.JTextField();
        txtAno = new javax.swing.JFormattedTextField();
        cbAtivo = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtObservacoes = new javax.swing.JTextArea();
        txtIdVeiculo = new javax.swing.JTextField();
        txtIdCliente = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtResultadoIdCliente = new javax.swing.JTextField();
        txtModelo = new javax.swing.JTextField();
        txtPlaca = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(51, 204, 255));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tela/logo (4).png"))); // NOI18N

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tela/logo (2).png"))); // NOI18N

        txtMarca.setBorder(javax.swing.BorderFactory.createTitledBorder("Marca:"));
        txtMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMarcaActionPerformed(evt);
            }
        });

        txtCor.setBorder(javax.swing.BorderFactory.createTitledBorder("Cor:"));
        txtCor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorActionPerformed(evt);
            }
        });

        txtAno.setBorder(javax.swing.BorderFactory.createTitledBorder("Ano:"));
        try {
            txtAno.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtAno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAnoActionPerformed(evt);
            }
        });

        cbAtivo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbAtivo.setText("Ativo");
        cbAtivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbAtivoActionPerformed(evt);
            }
        });

        txtObservacoes.setColumns(20);
        txtObservacoes.setRows(5);
        txtObservacoes.setBorder(javax.swing.BorderFactory.createTitledBorder("Observações:"));
        txtObservacoes.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                txtObservacoesAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(txtObservacoes);

        txtIdVeiculo.setBorder(javax.swing.BorderFactory.createTitledBorder("ID Veículo:"));
        txtIdVeiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdVeiculoActionPerformed(evt);
            }
        });

        txtIdCliente.setBorder(javax.swing.BorderFactory.createTitledBorder("ID Cliente:"));
        txtIdCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdClienteActionPerformed(evt);
            }
        });

        btnCadastrar.setBackground(new java.awt.Color(0, 153, 255));
        btnCadastrar.setForeground(new java.awt.Color(255, 255, 255));
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        btnFechar.setBackground(new java.awt.Color(0, 0, 153));
        btnFechar.setForeground(new java.awt.Color(255, 255, 255));
        btnFechar.setText("Fechar");
        btnFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFecharActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtResultadoIdCliente.setBackground(new java.awt.Color(220, 220, 220));
        txtResultadoIdCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtResultadoIdClienteActionPerformed(evt);
            }
        });

        txtModelo.setBorder(javax.swing.BorderFactory.createTitledBorder("Modelo: "));

        txtPlaca.setBorder(javax.swing.BorderFactory.createTitledBorder("Placa: "));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtAno, javax.swing.GroupLayout.DEFAULT_SIZE, 396, Short.MAX_VALUE)
                            .addComponent(txtCor)
                            .addComponent(txtMarca)
                            .addComponent(txtIdCliente)
                            .addComponent(txtIdVeiculo, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtResultadoIdCliente))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 6, Short.MAX_VALUE)
                        .addComponent(jLabel1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbAtivo)
                                    .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(14, 14, 14))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtIdVeiculo, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtIdCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtResultadoIdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtAno, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtCor, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cbAtivo)
                                .addGap(69, 69, 69))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMarcaActionPerformed

    }//GEN-LAST:event_txtMarcaActionPerformed

    private void txtAnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAnoActionPerformed

    }//GEN-LAST:event_txtAnoActionPerformed

    private void cbAtivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbAtivoActionPerformed
        
    }//GEN-LAST:event_cbAtivoActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
                dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
    String placa = txtPlaca.getText().trim().toUpperCase();
    String marca = txtMarca.getText().trim().toUpperCase();
    String modelo = txtModelo.getText().trim().toUpperCase();
    String cor = txtCor.getText().trim().toUpperCase();
    String observacao = txtObservacoes.getText().trim().toUpperCase();
    boolean ativo = cbAtivo.isSelected();

    int idCliente = 0;
    try {
        idCliente = Integer.parseInt(txtIdCliente.getText().trim());
    } catch (NumberFormatException erro) {
        JOptionPane.showMessageDialog(this, "Digite um ID de cliente válido.");
        txtIdCliente.requestFocus();
        return;
    }

    if (placa.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Informe a placa!");
        txtPlaca.requestFocus();
        return;
    }
    if (marca.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Informe a marca!");
        txtMarca.requestFocus();
        return;
    }
    if (modelo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Informe o modelo!");
        txtModelo.requestFocus();
        return;
    }

    int ano = 0;
    try {
        ano = Integer.parseInt(txtAno.getText().trim());
    } catch (NumberFormatException erro) {
        JOptionPane.showMessageDialog(this, "Digite um ano válido!");
        txtAno.requestFocus();
        return;
    }

    if (ano > 2100 || ano < 1900) {
        JOptionPane.showMessageDialog(this,
                "Digite um ano entre 1900 e 2100",
                "Ano inválido",
                JOptionPane.WARNING_MESSAGE);
        txtAno.requestFocus();
        return;
    }

    String sqlInsert = """
                       INSERT INTO veiculo
                       (cliente_id, placa, marca, modelo, ano, cor, observacao, ativo)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                       """;

    try (Connection conex = Conexao.conectar()) {

        try (PreparedStatement buscaCliente = conex.prepareStatement(
                "SELECT ativo FROM cliente WHERE id = ?")) {

            buscaCliente.setInt(1, idCliente);

            try (ResultSet rs = buscaCliente.executeQuery()) {
                if (!rs.next()) {
                    JOptionPane.showMessageDialog(this, "Cliente não encontrado!");
                    return;
                }
                if (!rs.getBoolean("ativo")) {
                    JOptionPane.showMessageDialog(this, "Este cliente está inativo!");
                    return;
                }
            }
        }

        try (PreparedStatement buscaPlaca = conex.prepareStatement(
                "SELECT COUNT(*) AS total FROM veiculo WHERE placa = ?")) {

            buscaPlaca.setString(1, placa);

            try (ResultSet rs = buscaPlaca.executeQuery()) {
                if (rs.next() && rs.getInt("total") > 0) {
                    JOptionPane.showMessageDialog(this, "Já existe um veículo com esta placa!");
                    return;
                }
            }
        }

        try (PreparedStatement stmt = conex.prepareStatement(sqlInsert)) {
            stmt.setInt(1, idCliente);
            stmt.setString(2, placa);
            stmt.setString(3, marca);
            stmt.setString(4, modelo);
            stmt.setInt(5, ano);
            stmt.setString(6, cor);
            stmt.setString(7, observacao);
            stmt.setBoolean(8, ativo);

            int linhas = stmt.executeUpdate();
            if (linhas > 0) {
                JOptionPane.showMessageDialog(this, "Cadastro do veículo realizado com sucesso!");
                limparCampos();
                txtIdCliente.requestFocus();
            }
        }

    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(this, "Não foi possível cadastrar o veículo! - Erro: " + erro.getMessage());
    }

    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnLimparActionPerformed

    private void txtIdClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdClienteActionPerformed
        
    }//GEN-LAST:event_txtIdClienteActionPerformed

    private void txtIdVeiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdVeiculoActionPerformed
        
    }//GEN-LAST:event_txtIdVeiculoActionPerformed

    private void txtCorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorActionPerformed

    private void txtResultadoIdClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtResultadoIdClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtResultadoIdClienteActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
    int idCliente = 0;
    try {
        idCliente = Integer.parseInt(txtIdCliente.getText().trim());
    } catch (NumberFormatException erro) {
        JOptionPane.showMessageDialog(this, "Digite um ID de cliente válido.");
        return;
    }

    String sql = "SELECT nome, ativo FROM cliente WHERE id = ?";

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql)) {

        stmt.setInt(1, idCliente);

        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                if (!rs.getBoolean("ativo")) {
                    txtResultadoIdCliente.setText("");
                    JOptionPane.showMessageDialog(this, "Este cliente está inativo!");
                } else {
                    txtResultadoIdCliente.setText(rs.getString("nome"));
                }
            } else {
                txtResultadoIdCliente.setText("");
                JOptionPane.showMessageDialog(this, "Cliente não encontrado!");
            }
        }

    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(this, "Erro ao buscar cliente:\n" + erro.getMessage());
    }

    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtObservacoesAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_txtObservacoesAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_txtObservacoesAncestorAdded

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmCadastroVeiculo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmCadastroVeiculo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmCadastroVeiculo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmCadastroVeiculo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmCadastroVeiculo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JCheckBox cbAtivo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JFormattedTextField txtAno;
    private javax.swing.JTextField txtCor;
    private javax.swing.JTextField txtIdCliente;
    private javax.swing.JTextField txtIdVeiculo;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtModelo;
    private javax.swing.JTextArea txtObservacoes;
    private javax.swing.JTextField txtPlaca;
    private javax.swing.JTextField txtResultadoIdCliente;
    // End of variables declaration//GEN-END:variables
}
